package testclass;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

  public class BaseClass {
	public static WebDriver openbrowser()
	{
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\Pravin Magar\\chromedriver_win32 (1)\\chromedriver.exe");
     WebDriver driver = new ChromeDriver();
     driver.manage().window().maximize();
     return driver;
}

}
