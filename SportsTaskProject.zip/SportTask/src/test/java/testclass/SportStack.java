package testclass;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pom.CricketPom;

public class SportStack extends BaseClass {
	
	WebDriver driver;
	CricketPom obj;
	@BeforeTest
	public void beforetest()
	{
		driver=openbrowser();
	}
	@BeforeClass
	public void beforeclass()
	{
		obj=new CricketPom(driver);
		driver.get("https://thesportstak.com/");
	}
	/*@BeforeMethod
	
	public void beforemethod()
	{
		driver.navigate().toback("https://thesportstak.com/");
	}*/
	@Test(priority=1)
	public void test1() throws InterruptedException
	{
	
		obj.cricketclick();
		Thread.sleep(3000);
		obj.lighttheme();
		Thread.sleep(2000);
		JavascriptExecutor js =(JavascriptExecutor)driver;
		  js.executeScript("window.scrollBy(0,document.body.scrollHeight)","");
		  Thread.sleep(3000);
	   obj.scroll();
		Thread.sleep(5000);
	
	}
	@Test(priority=2)
	public void test2() throws InterruptedException
	{
		String url="";
	      List<WebElement> allURLs = driver.findElements(By.tagName("a"));
	      System.out.println("Total links on the Wb Page: " + allURLs.size());
	      java.util.Iterator<WebElement> iterator = allURLs.iterator();
	      while (iterator.hasNext()) {
	    	  url = iterator.next().getText();
	    	  System.out.println(url);
	    	  Thread.sleep(4000);
	      }
	}
	@Test(priority=3)
	public void test3()
	{
		  String homePage = "https://thesportstak.com/";
		String url = "";
        HttpURLConnection huc = null;
        int respCode = 200;
		  List<WebElement> links = driver.findElements(By.tagName("a"));
	        
	        java.util.Iterator<WebElement> it = links.iterator();
	        
	        while(it.hasNext()){
	            
	            url = it.next().getAttribute("href");
	            
	            System.out.println(url);
	        
	            if(url == null || url.isEmpty()){
	System.out.println("URL is either not configured for anchor tag or it is empty");
	                continue;
	            }
	            
	            if(!url.startsWith(homePage)){
	                System.out.println("URL belongs to another domain, skipping it.");
	                continue;
	            }
	            
	            try {
	                huc = (HttpURLConnection)(new URL(url).openConnection());
	                
	                huc.setRequestMethod("HEAD");
	                
	                huc.connect();
	                
	                respCode = huc.getResponseCode();
	                
	                if(respCode >= 400){
	                    System.out.println(url+" is a broken link");
	                }
	                else{
	                    System.out.println(url+" is a valid link");
	                }
	                    
	            } catch (MalformedURLException e) {	                
	                e.printStackTrace();
	            } catch (IOException e) {	                
	                e.printStackTrace();
	            }
	        }
	    }
@AfterMethod
	public void aftermethod()
{	}
	@AfterClass
	public void afterclass()
	{
		driver.quit();
	}
}

