package pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CricketPom {
	WebDriver driver;
	@FindBy(xpath="//span[text()='Cricket'][1]")
	private WebElement cricket;
	@FindBy(xpath="//div[@class='quick-links'][3]")
	private WebElement scrolld;
	@FindBy(xpath="//span[text()='Dark']")
	private WebElement theme;
	
	public CricketPom(WebDriver driver)
	{
		PageFactory.initElements(driver,this);
		
	}
	public void cricketclick()
	{
		
		cricket.click();
	}
	public void scroll()
	{
		
		System.out.println(scrolld.getText());
	
	}
	public void  lighttheme()
	{
		theme.click();
	}
	
	

}
